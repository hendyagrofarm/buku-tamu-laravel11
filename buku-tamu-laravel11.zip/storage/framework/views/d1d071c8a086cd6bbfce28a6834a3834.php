<?php $__env->startSection('title', 'Check In Tamu'); ?>
<?php $__env->startSection('content'); ?>
<header class="sticky top-0 z-20 bg-[#173b5b] px-5 py-4 text-white sm:px-8">
    <div class="flex items-center gap-4">
        <a href="<?php echo e(route('kiosk.home')); ?>" class="grid h-11 w-11 place-items-center rounded-xl bg-white/10 text-xl" aria-label="Kembali">←</a>
        <div><p class="text-xs text-blue-100">BukuTamu</p><h1 class="text-lg font-bold">Check In Tamu</h1></div>
    </div>
</header>
<main class="px-5 py-6 sm:px-8 sm:py-8">
    <div class="mb-6 rounded-2xl border border-blue-100 bg-blue-50 p-4 text-sm leading-6 text-[#173b5b]">Lokasi: <strong><?php echo e($location->name); ?></strong>. Isi data tamu. Setelah disimpan, survey kepuasan akan terbuka otomatis.</div>
    <?php if($errors->any()): ?>
        <div class="mb-6 rounded-2xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
            <p class="font-bold">Periksa kembali data berikut:</p>
            <ul class="mt-2 list-disc space-y-1 pl-5"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
        </div>
    <?php endif; ?>
    <form method="POST" action="<?php echo e(route('kiosk.visit.store')); ?>" class="space-y-5"><?php echo csrf_field(); ?>
        <div><label class="mb-2 block text-sm font-bold">Nama lengkap *</label><input name="name" value="<?php echo e(old('name')); ?>" required class="w-full rounded-2xl border border-slate-300 bg-white px-4 py-4 text-base outline-none focus:border-blue-600 focus:ring-4 focus:ring-blue-100" placeholder="Nama sesuai identitas"></div>
        <div><label class="mb-2 block text-sm font-bold">Nomor telepon *</label><input name="phone" value="<?php echo e(old('phone')); ?>" inputmode="tel" required class="w-full rounded-2xl border border-slate-300 bg-white px-4 py-4 text-base outline-none focus:border-blue-600 focus:ring-4 focus:ring-blue-100" placeholder="08xxxxxxxxxx"></div>
        <div><label class="mb-2 block text-sm font-bold">Asal perusahaan/instansi *</label><input name="company" value="<?php echo e(old('company')); ?>" required class="w-full rounded-2xl border border-slate-300 bg-white px-4 py-4 text-base outline-none focus:border-blue-600 focus:ring-4 focus:ring-blue-100"></div>
        <div><label class="mb-2 block text-sm font-bold">Bertemu dengan *</label><select name="employee_id" required class="w-full rounded-2xl border border-slate-300 bg-white px-4 py-4 text-base outline-none focus:border-blue-600 focus:ring-4 focus:ring-blue-100"><option value="">Pilih pegawai tujuan</option><?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($employee->id); ?>" <?php if(old('employee_id') == $employee->id): echo 'selected'; endif; ?>><?php echo e($employee->name); ?> — <?php echo e($employee->position); ?> (<?php echo e($employee->division->name); ?>)</option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
        <div><label class="mb-2 block text-sm font-bold">Keperluan kunjungan *</label><textarea name="purpose" rows="4" required class="w-full rounded-2xl border border-slate-300 bg-white px-4 py-4 text-base outline-none focus:border-blue-600 focus:ring-4 focus:ring-blue-100" placeholder="Jelaskan tujuan kunjungan secara singkat"><?php echo e(old('purpose')); ?></textarea></div>
        <div><label class="mb-2 block text-sm font-bold">Jumlah orang *</label><input type="number" min="1" max="20" name="number_of_people" value="<?php echo e(old('number_of_people', 1)); ?>" required class="w-full rounded-2xl border border-slate-300 bg-white px-4 py-4 text-base outline-none focus:border-blue-600 focus:ring-4 focus:ring-blue-100"></div>
        <label class="flex items-start gap-3 rounded-2xl bg-slate-100 p-4 text-sm leading-6 text-slate-600"><input type="checkbox" name="privacy" value="1" class="mt-1 h-5 w-5 rounded border-slate-300 text-blue-700" <?php if(old('privacy')): echo 'checked'; endif; ?>><span>Saya menyetujui penggunaan data ini untuk pencatatan dan keamanan kunjungan.</span></label>
        <button class="w-full rounded-2xl bg-[#173b5b] px-5 py-4 text-base font-extrabold text-white shadow-lg shadow-blue-900/20 active:scale-[.99]">Simpan dan Isi Survey</button>
    </form>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.kiosk', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\buku-tamu-laravel11\resources\views/kiosk/register.blade.php ENDPATH**/ ?>